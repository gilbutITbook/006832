package org.androidtown.study09;

/**
 * Created by user on 2015-08-19.
 */
public class Singer {

    String name;

    int age;

    public Singer(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

}
