package org.androidtown.study12;

public class GirlGroupSinger extends Singer {
	
	public GirlGroupSinger() {
		super();
	}
	
	public GirlGroupSinger(String name, int age) {
		super(name, age);
	}
	
}
