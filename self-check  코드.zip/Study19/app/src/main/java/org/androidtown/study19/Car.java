package org.androidtown.study19;

public interface Car {

	public void doStart();
	
	public void doRun();
	
	public void doTurn();
	
	public void doStop();
	
}
