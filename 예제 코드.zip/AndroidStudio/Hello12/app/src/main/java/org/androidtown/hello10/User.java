package org.androidtown.hello10;

/**
 * Created by user on 2015-07-18.
 */
public class User {

    public static String loginName;

    public static final int REQ_CODE_PHONEBOOK = 1;

    public static final int RES_CODE_SUCCESS = 200;
    public static final int RES_CODE_FAILURE = 400;

}
