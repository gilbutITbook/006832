package org.androidtown.calculator;

/**
 * Created by user on 2015-07-19.
 */
public class MyCalculator implements Calculator {

    public int add(int a, int b) {
        return a + b;
    }

}
