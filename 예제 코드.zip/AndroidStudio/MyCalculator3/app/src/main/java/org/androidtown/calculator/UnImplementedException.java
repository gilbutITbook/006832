package org.androidtown.calculator;

/**
 * Created by user on 2015-07-19.
 */
public class UnImplementedException extends Exception {

    public UnImplementedException() {
        super();
    }

    public UnImplementedException(String name) {
        super(name);
    }

}
