package org.androidtown.file;

import java.io.Serializable;

/**
 * Created by user on 2015-07-19.
 */
public class Person implements Serializable {

    String name;

    int age;

}
