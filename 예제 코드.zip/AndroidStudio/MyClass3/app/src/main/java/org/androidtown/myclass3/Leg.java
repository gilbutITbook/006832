package org.androidtown.myclass3;

/**
 * Created by user on 2015-07-18.
 */
public class Leg {
    String left = "왼쪽";
    String right = "오른쪽";

    public String getLeft() {
        return left;
    }

    public void setLeft(String left) {
        this.left = left;
    }

    public String getRight() {
        return right;
    }

    public void setRight(String right) {
        this.right = right;
    }

}
